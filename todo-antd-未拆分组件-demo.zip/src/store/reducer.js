const defaultState = {
    inputValue: '',
    list: [],
    visible: false
};

// reducer可以接收state,但是绝不可以修改state
export default ((state = defaultState, action) => {
    // console.log(state,action);
    if(action.type === 'change_input_value'){
        const newState = JSON.parse(JSON.stringify(state));
        newState.inputValue = action.value;
        return newState;
    }
    if(action.type === 'add_todo_item'){
        const newState = JSON.parse(JSON.stringify(state));
        if(!newState.inputValue) {
            newState.visible = true;
            return newState;
        }
        newState.list.push(newState.inputValue);
        newState.inputValue = '';
        return newState;
    }
    if(action.type === "model_visible"){
        const newState = JSON.parse(JSON.stringify(state));
        newState.visible = action.value;
        return newState;
    }
    if(action.type === 'delete_todo_item'){
        const newState = JSON.parse(JSON.stringify(state));
        newState.list.splice(action.value,1);        
        return newState;
    }

    return state;
})