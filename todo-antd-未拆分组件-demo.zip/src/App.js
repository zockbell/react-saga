import React, { Component } from 'react';
import { Input, Button, List, Alert } from 'antd';
import 'antd/dist/antd.css';
import store from './store/index'


class App extends Component {

  constructor(props){
    super(props);
    // console.log(store.getState());
    this.state = store.getState();

    this.handleChange = this.handleChange.bind(this);
    this.handleStoreChange = this.handleStoreChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);

    store.subscribe(this.handleStoreChange);  //监听（订阅store的变化）    
  }

  render() {
    return (
      <div style={{paddingTop: '10px', paddingLeft: '10px'}}>
        <div>
          <Input 
            value={this.state.inputValue} 
            placeholder="请输入内容" 
            style={{width: '300px', marginRight: '10px'}} 
            onChange={this.handleChange}
            onKeyDown={this.handleKeydown.bind(this)}
          />
          <Button type="primary" onClick={this.handleSubmit}>提交</Button>
        </div>
        <List
          size="small"          
          style={{marginTop: '5px', width: '300px', cursor: 'pointer'}}
          bordered
          dataSource={this.state.list}
          renderItem={(item, index) => (<List.Item onClick={this.handleDelete.bind(this, index)}>{item}-{index}</List.Item>)}
        />
        <div>
          {
            this.state.visible ? (
              <Alert
                message="内容不能为空"
                type="error"
                closable
                afterClose={this.handleClose}
              />
            ) : null
          }
        </div>
      </div>
    );
  }

  // 输入框变化
  handleChange(e){
    const action = {
      type: 'change_input_value',
      value: e.target.value
    }
    store.dispatch(action);
  }

  // 监听并更新最新的store
  handleStoreChange(){
    this.setState(store.getState());
  }

  // 提交
  handleSubmit(){
    const action = {
      type: 'add_todo_item',
    };
    store.dispatch(action);
  }

  // 回车事件
  handleKeydown = (e) => {
    if(e.keyCode === 13){
      this.handleSubmit();
    }
  }

  // 删除
  handleDelete(index){    
    const action = {
      type: 'delete_todo_item',
      value: index
    };
    store.dispatch(action);
  }

  // 模态提示框
  handleClose = () => {
    // this.setState({ visible: false });
    const action = {
      type: 'model_visible',
      value: false
    };
    store.dispatch(action);
  }

}

export default App;
